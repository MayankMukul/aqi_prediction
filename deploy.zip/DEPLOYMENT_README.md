# AQI Prediction System - Deployment

## 🚀 Quick Start Deployment

### Option 1: Streamlit Cloud (Recommended - FREE & Easy)

1. **Prepare files:**
```bash
# Make sure you have these files:
# - streamlit_app.py
# - requirements_streamlit.txt
# - aqi_model.pkl
```

2. **Push to GitHub:**
```bash
git init
git add streamlit_app.py requirements_streamlit.txt aqi_model.pkl
git commit -m "Deploy AQI predictor"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/aqi-predictor.git
git push -u origin main
```

3. **Deploy:**
- Go to https://share.streamlit.io
- Click "New app"
- Select your repository
- Main file: `streamlit_app.py`
- Click "Deploy"

**Your app will be live at:** `https://YOUR_USERNAME-aqi-predictor.streamlit.app`

---

### Option 2: Run Locally

#### Streamlit App
```bash
# Install dependencies
pip install -r requirements_streamlit.txt

# Run app
streamlit run streamlit_app.py
```
Access at: http://localhost:8501

#### Flask API
```bash
# Install dependencies
pip install -r requirements_flask.txt

# Run API
python flask_api.py
```
Access at: http://localhost:5000

---

### Option 3: Docker Deployment

```bash
# Build image
docker build -t aqi-predictor .

# Run container
docker run -p 8501:8501 aqi-predictor

# Or use docker-compose
docker-compose up
```

---

### Option 4: Heroku Deployment (API)

```bash
# Login to Heroku
heroku login

# Create app
heroku create your-aqi-api

# Add buildpack
heroku buildpacks:add heroku/python

# Deploy
git push heroku main

# Open app
heroku open
```

Your API will be at: `https://your-aqi-api.herokuapp.com`

---

## 📝 Testing Your Deployment

### Test Streamlit App
1. Open the URL
2. Adjust sliders
3. Click "Predict AQI"
4. See results!

### Test Flask API

**Using curl:**
```bash
curl -X POST https://your-api-url.com/predict \
  -H "Content-Type: application/json" \
  -d '{
    "pm25": 75,
    "pm10": 110,
    "no2": 45,
    "so2": 22,
    "o3": 65,
    "co": 1.8
  }'
```

**Using Python:**
```python
import requests

response = requests.post(
    'https://your-api-url.com/predict',
    json={
        'pm25': 75,
        'pm10': 110,
        'no2': 45,
        'so2': 22,
        'o3': 65,
        'co': 1.8
    }
)

print(response.json())
```

---

## 🎯 What to Add to Your Resume

**Before:** ❌
> "Built a machine learning model for AQI prediction"

**After:** ✅
> "Developed and deployed AQI prediction web application with interactive UI, serving real-time predictions via Streamlit Cloud (streamlit.app/your-app)"

**Advanced:** ⭐
> "Built full-stack ML application: trained Random Forest model (R²=0.98), created REST API with Flask, deployed on Heroku with 99.9% uptime, and built responsive web interface with Streamlit"

---

## 📱 Show in Interview

1. **Live Demo:** Open your deployed app URL
2. **Show Code:** Walk through streamlit_app.py or flask_api.py
3. **API Testing:** Demonstrate API with Postman/curl
4. **Docker:** `docker run` command to show containerization

---

## 🔧 Troubleshooting

**Streamlit app not loading?**
- Check requirements.txt has all dependencies
- Ensure aqi_model.pkl is in repository
- Check Streamlit Cloud logs

**Flask API errors?**
- Verify model file path
- Check CORS settings if frontend issues
- Review Heroku logs: `heroku logs --tail`

**Docker build fails?**
- Check Dockerfile syntax
- Ensure all files are in build context
- Try: `docker build --no-cache -t aqi-predictor .`

---

## 📊 Files Needed for Deployment

### For Streamlit:
- ✅ streamlit_app.py
- ✅ requirements_streamlit.txt  
- ✅ aqi_model.pkl

### For Flask API:
- ✅ flask_api.py
- ✅ requirements_flask.txt
- ✅ aqi_model.pkl
- ✅ Procfile (for Heroku)

### For Docker:
- ✅ Dockerfile
- ✅ docker-compose.yml
- ✅ All app files

---

## 🎓 Next Steps

1. ✅ Deploy to Streamlit Cloud
2. ✅ Add link to resume
3. ✅ Add to GitHub README
4. ✅ Create demo video
5. ✅ Share on LinkedIn

---

**Need help?** Check DEPLOYMENT_GUIDE.md for detailed instructions!
