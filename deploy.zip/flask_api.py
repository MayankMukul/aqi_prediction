"""
AQI Prediction REST API - Flask
--------------------------------
Production-ready API for AQI predictions
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import pandas as pd
import numpy as np
import pickle
from datetime import datetime
import logging

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for frontend access

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load model
try:
    with open('aqi_model.pkl', 'rb') as f:
        model_data = pickle.load(f)
    model = model_data['model']
    scaler = model_data['scaler']
    logger.info("Model loaded successfully")
except FileNotFoundError:
    model = None
    scaler = None
    logger.warning("Model file not found - running in demo mode")

def categorize_aqi(aqi):
    """Convert AQI value to category and recommendations"""
    if aqi <= 50:
        return {
            "category": "Good",
            "color": "green",
            "emoji": "✅",
            "health_impact": "Minimal",
            "recommendation": "Air quality is satisfactory. Enjoy outdoor activities!"
        }
    elif aqi <= 100:
        return {
            "category": "Moderate", 
            "color": "yellow",
            "emoji": "⚠️",
            "health_impact": "Acceptable",
            "recommendation": "Acceptable for most. Sensitive groups should limit prolonged outdoor exertion."
        }
    elif aqi <= 150:
        return {
            "category": "Unhealthy for Sensitive Groups",
            "color": "orange",
            "emoji": "🔶",
            "health_impact": "Unhealthy for Sensitive",
            "recommendation": "Sensitive groups should reduce outdoor exertion."
        }
    elif aqi <= 200:
        return {
            "category": "Unhealthy",
            "color": "red",
            "emoji": "🚫",
            "health_impact": "Unhealthy",
            "recommendation": "Everyone should reduce prolonged outdoor exertion."
        }
    elif aqi <= 300:
        return {
            "category": "Very Unhealthy",
            "color": "purple",
            "emoji": "⛔",
            "health_impact": "Very Unhealthy",
            "recommendation": "Avoid outdoor activities. Stay indoors."
        }
    else:
        return {
            "category": "Hazardous",
            "color": "maroon",
            "emoji": "🚨",
            "health_impact": "Hazardous",
            "recommendation": "Emergency conditions! Everyone should avoid all outdoor exertion."
        }

# HTML template for API documentation
API_DOCS = """
<!DOCTYPE html>
<html>
<head>
    <title>AQI Prediction API</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .container {
            background: white;
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
        }
        h1 {
            color: #667eea;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
        }
        h2 {
            color: #764ba2;
            margin-top: 30px;
        }
        .endpoint {
            background: #f8f9fa;
            padding: 20px;
            margin: 15px 0;
            border-left: 4px solid #667eea;
            border-radius: 5px;
        }
        .method {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 5px;
            font-weight: bold;
            margin-right: 10px;
        }
        .get { background: #28a745; color: white; }
        .post { background: #007bff; color: white; }
        code {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 15px;
            display: block;
            border-radius: 5px;
            overflow-x: auto;
            margin: 10px 0;
        }
        .example {
            background: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            margin: 10px 0;
        }
        .status-good { color: #28a745; font-weight: bold; }
        .status-error { color: #dc3545; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌍 AQI Prediction API Documentation</h1>
        <p><strong>Version:</strong> 1.0.0 | <strong>Status:</strong> <span class="status-good">● Active</span></p>
        
        <h2>📋 Overview</h2>
        <p>REST API for predicting Air Quality Index (AQI) based on pollutant concentrations.</p>
        
        <h2>🔗 Endpoints</h2>
        
        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/</strong>
            <p>API documentation (this page)</p>
        </div>
        
        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/health</strong>
            <p>Health check endpoint</p>
            <div class="example">
                <strong>Response:</strong>
                <code>{"status": "healthy", "model_loaded": true, "timestamp": "2024-..."}</code>
            </div>
        </div>
        
        <div class="endpoint">
            <span class="method post">POST</span>
            <strong>/predict</strong>
            <p>Predict AQI from pollutant data</p>
            
            <strong>Request Body:</strong>
            <code>{
  "pm25": 50.0,
  "pm10": 75.0,
  "no2": 40.0,
  "so2": 20.0,
  "o3": 60.0,
  "co": 1.5
}</code>
            
            <strong>Response:</strong>
            <code>{
  "success": true,
  "aqi": 125.5,
  "category": "Unhealthy for Sensitive Groups",
  "color": "orange",
  "emoji": "🔶",
  "health_impact": "Unhealthy for Sensitive",
  "recommendation": "Sensitive groups should reduce outdoor exertion.",
  "timestamp": "2024-01-15T10:30:00",
  "input": {...}
}</code>
        </div>
        
        <div class="endpoint">
            <span class="method get">GET</span>
            <strong>/api/info</strong>
            <p>Get API information and statistics</p>
        </div>
        
        <h2>💻 Example Usage</h2>
        
        <h3>cURL</h3>
        <code>curl -X POST http://localhost:5000/predict \\
  -H "Content-Type: application/json" \\
  -d '{"pm25": 75, "pm10": 110, "no2": 45, "so2": 22, "o3": 65, "co": 1.8}'</code>
        
        <h3>Python</h3>
        <code>import requests

data = {
    "pm25": 75.0,
    "pm10": 110.0,
    "no2": 45.0,
    "so2": 22.0,
    "o3": 65.0,
    "co": 1.8
}

response = requests.post("http://localhost:5000/predict", json=data)
print(response.json())</code>
        
        <h3>JavaScript</h3>
        <code>fetch('http://localhost:5000/predict', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({
    pm25: 75, pm10: 110, no2: 45,
    so2: 22, o3: 65, co: 1.8
  })
})
.then(res => res.json())
.then(data => console.log(data));</code>
        
        <h2>📊 Pollutant Ranges</h2>
        <ul>
            <li><strong>PM2.5:</strong> 0-500 μg/m³</li>
            <li><strong>PM10:</strong> 0-600 μg/m³</li>
            <li><strong>NO₂:</strong> 0-200 μg/m³</li>
            <li><strong>SO₂:</strong> 0-100 μg/m³</li>
            <li><strong>O₃:</strong> 0-300 μg/m³</li>
            <li><strong>CO:</strong> 0-10 mg/m³</li>
        </ul>
        
        <h2>📈 AQI Categories</h2>
        <table style="width:100%; border-collapse: collapse;">
            <tr style="background: #f8f9fa;">
                <th style="padding: 10px; border: 1px solid #ddd;">AQI Range</th>
                <th style="padding: 10px; border: 1px solid #ddd;">Category</th>
                <th style="padding: 10px; border: 1px solid #ddd;">Color</th>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">0-50</td>
                <td style="padding: 10px; border: 1px solid #ddd;">Good</td>
                <td style="padding: 10px; border: 1px solid #ddd; background: #28a745; color: white;">Green</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">51-100</td>
                <td style="padding: 10px; border: 1px solid #ddd;">Moderate</td>
                <td style="padding: 10px; border: 1px solid #ddd; background: #ffc107;">Yellow</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">101-150</td>
                <td style="padding: 10px; border: 1px solid #ddd;">Unhealthy for Sensitive</td>
                <td style="padding: 10px; border: 1px solid #ddd; background: #fd7e14; color: white;">Orange</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">151-200</td>
                <td style="padding: 10px; border: 1px solid #ddd;">Unhealthy</td>
                <td style="padding: 10px; border: 1px solid #ddd; background: #dc3545; color: white;">Red</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">201-300</td>
                <td style="padding: 10px; border: 1px solid #ddd;">Very Unhealthy</td>
                <td style="padding: 10px; border: 1px solid #ddd; background: #6f42c1; color: white;">Purple</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">301-500</td>
                <td style="padding: 10px; border: 1px solid #ddd;">Hazardous</td>
                <td style="padding: 10px; border: 1px solid #ddd; background: #6c0d0d; color: white;">Maroon</td>
            </tr>
        </table>
        
        <hr style="margin: 40px 0;">
        <p style="text-align: center; color: gray;">
            Built with Flask | Machine Learning | Data Science Project<br>
            © 2024 AQI Predictor API
        </p>
    </div>
</body>
</html>
"""

@app.route('/')
def home():
    """API documentation page"""
    return render_template_string(API_DOCS)

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "model_loaded": model is not None,
        "timestamp": datetime.now().isoformat(),
        "version": "1.0.0"
    }), 200

@app.route('/api/info')
def api_info():
    """API information endpoint"""
    return jsonify({
        "name": "AQI Prediction API",
        "version": "1.0.0",
        "description": "Machine Learning API for Air Quality Index prediction",
        "endpoints": {
            "/": "API documentation",
            "/health": "Health check",
            "/predict": "AQI prediction (POST)",
            "/api/info": "API information"
        },
        "model": {
            "algorithm": "Random Forest Regressor",
            "features": ["pm25", "pm10", "no2", "so2", "o3", "co"],
            "loaded": model is not None
        }
    })

@app.route('/predict', methods=['POST'])
def predict():
    """
    Predict AQI from pollutant concentrations
    
    Request body example:
    {
        "pm25": 50.0,
        "pm10": 75.0,
        "no2": 40.0,
        "so2": 20.0,
        "o3": 60.0,
        "co": 1.5
    }
    """
    try:
        # Get JSON data
        data = request.get_json()
        
        if not data:
            return jsonify({
                "success": False,
                "error": "No data provided"
            }), 400
        
        # Validate required fields
        required_fields = ['pm25', 'pm10', 'no2', 'so2', 'o3', 'co']
        missing_fields = [field for field in required_fields if field not in data]
        
        if missing_fields:
            return jsonify({
                "success": False,
                "error": f"Missing required fields: {', '.join(missing_fields)}"
            }), 400
        
        # Create input DataFrame
        input_df = pd.DataFrame({
            'pm25': [float(data['pm25'])],
            'pm10': [float(data['pm10'])],
            'no2': [float(data['no2'])],
            'so2': [float(data['so2'])],
            'o3': [float(data['o3'])],
            'co': [float(data['co'])]
        })
        
        # Make prediction
        if model is not None and scaler is not None:
            # Real prediction
            input_scaled = scaler.transform(input_df)
            prediction = float(model.predict(input_scaled)[0])
        else:
            # Demo mode - simple calculation
            prediction = float(
                data['pm25'] * 2.5 + 
                data['pm10'] * 0.5 + 
                data['no2'] * 0.8
            )
        
        # Get category information
        category_info = categorize_aqi(prediction)
        
        # Log prediction
        logger.info(f"Prediction made: AQI={prediction:.2f}, Category={category_info['category']}")
        
        # Return response
        return jsonify({
            "success": True,
            "aqi": round(prediction, 2),
            "category": category_info["category"],
            "color": category_info["color"],
            "emoji": category_info["emoji"],
            "health_impact": category_info["health_impact"],
            "recommendation": category_info["recommendation"],
            "timestamp": datetime.now().isoformat(),
            "input": data
        })
    
    except ValueError as e:
        return jsonify({
            "success": False,
            "error": f"Invalid input values: {str(e)}"
        }), 400
    
    except Exception as e:
        logger.error(f"Prediction error: {str(e)}")
        return jsonify({
            "success": False,
            "error": "Internal server error"
        }), 500

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return jsonify({
        "success": False,
        "error": "Endpoint not found"
    }), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    return jsonify({
        "success": False,
        "error": "Internal server error"
    }), 500

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🚀 AQI Prediction API Server Starting...")
    print("="*60)
    print(f"Model loaded: {model is not None}")
    print("Server: http://localhost:5000")
    print("Documentation: http://localhost:5000")
    print("Health check: http://localhost:5000/health")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
