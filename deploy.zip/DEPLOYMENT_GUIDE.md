# Complete Deployment Guide - AQI Prediction System

## 🚀 Deployment Options Overview

| Option | Difficulty | Cost | Best For |
|--------|-----------|------|----------|
| **Streamlit Web App** | ⭐ Easy | Free | Quick demo, portfolio |
| **Flask REST API** | ⭐⭐ Medium | Free | Mobile apps, integrations |
| **Docker Container** | ⭐⭐ Medium | Free | Reproducibility, scaling |
| **Heroku** | ⭐⭐ Medium | Free tier | Quick production deployment |
| **AWS Lambda** | ⭐⭐⭐ Hard | Pay-per-use | Serverless, auto-scaling |
| **Google Cloud Run** | ⭐⭐⭐ Hard | Free tier | Container deployment |

---

## 🌟 OPTION 1: Streamlit Web App (RECOMMENDED FOR BEGINNERS)

**Best for:** Portfolio, demonstration, quick prototyping

### Step 1: Create Streamlit App

```python
# File: streamlit_app.py

import streamlit as st
import pandas as pd
import numpy as np
import joblib
from datetime import datetime
import plotly.express as px
import plotly.graph_objects as go

# Page config
st.set_page_config(
    page_title="AQI Predictor",
    page_icon="🌍",
    layout="wide"
)

# Load model
@st.cache_resource
def load_model():
    """Load trained model"""
    try:
        import pickle
        with open('aqi_model.pkl', 'rb') as f:
            model_data = pickle.load(f)
        return model_data
    except:
        st.error("Model not found! Please train the model first.")
        return None

# Title
st.title("🌍 Air Quality Index (AQI) Prediction System")
st.markdown("Predict AQI based on pollutant concentrations")

# Sidebar - Input
st.sidebar.header("📊 Input Pollutant Levels")

pm25 = st.sidebar.slider("PM2.5 (μg/m³)", 0, 500, 50, 5)
pm10 = st.sidebar.slider("PM10 (μg/m³)", 0, 600, 75, 5)
no2 = st.sidebar.slider("NO₂ (μg/m³)", 0, 200, 40, 5)
so2 = st.sidebar.slider("SO₂ (μg/m³)", 0, 100, 20, 2)
o3 = st.sidebar.slider("O₃ (μg/m³)", 0, 300, 60, 5)
co = st.sidebar.slider("CO (mg/m³)", 0.0, 10.0, 1.5, 0.1)

# Create input dataframe
input_data = pd.DataFrame({
    'pm25': [pm25],
    'pm10': [pm10],
    'no2': [no2],
    'so2': [so2],
    'o3': [o3],
    'co': [co]
})

# Make prediction
if st.sidebar.button("🔮 Predict AQI", type="primary"):
    model_data = load_model()
    
    if model_data:
        model = model_data['model']
        scaler = model_data['scaler']
        
        # Scale input
        input_scaled = scaler.transform(input_data)
        
        # Predict
        prediction = model.predict(input_scaled)[0]
        
        # Determine category
        if prediction <= 50:
            category = "Good"
            color = "green"
            emoji = "✅"
        elif prediction <= 100:
            category = "Moderate"
            color = "yellow"
            emoji = "⚠️"
        elif prediction <= 200:
            category = "Poor"
            color = "orange"
            emoji = "🔶"
        else:
            category = "Severe"
            color = "red"
            emoji = "🚨"
        
        # Display results
        st.markdown("---")
        st.header("📈 Prediction Results")
        
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Predicted AQI", f"{prediction:.1f}")
        
        with col2:
            st.metric("Category", f"{emoji} {category}")
        
        with col3:
            st.metric("Health Impact", 
                     "Minimal" if prediction <= 50 else 
                     "Acceptable" if prediction <= 100 else
                     "Unhealthy" if prediction <= 200 else
                     "Hazardous")
        
        # Gauge chart
        fig = go.Figure(go.Indicator(
            mode = "gauge+number+delta",
            value = prediction,
            domain = {'x': [0, 1], 'y': [0, 1]},
            title = {'text': "AQI Level"},
            delta = {'reference': 100},
            gauge = {
                'axis': {'range': [None, 500]},
                'bar': {'color': color},
                'steps': [
                    {'range': [0, 50], 'color': "lightgreen"},
                    {'range': [50, 100], 'color': "lightyellow"},
                    {'range': [100, 200], 'color': "orange"},
                    {'range': [200, 500], 'color': "lightcoral"}
                ],
                'threshold': {
                    'line': {'color': "red", 'width': 4},
                    'thickness': 0.75,
                    'value': 200
                }
            }
        ))
        
        st.plotly_chart(fig, use_container_width=True)
        
        # Health recommendations
        st.markdown("---")
        st.header("💡 Health Recommendations")
        
        if category == "Good":
            st.success("Air quality is satisfactory. Enjoy outdoor activities!")
        elif category == "Moderate":
            st.warning("Acceptable for most people. Sensitive groups should limit prolonged outdoor exertion.")
        elif category == "Poor":
            st.error("Unhealthy for sensitive groups. Everyone should reduce prolonged outdoor exertion.")
        else:
            st.error("🚨 Health alert! Everyone should avoid outdoor activities. Stay indoors with air purifiers.")

# About section
with st.expander("ℹ️ About This App"):
    st.markdown("""
    ### Air Quality Index Prediction
    
    This application uses machine learning to predict Air Quality Index (AQI) 
    based on pollutant concentrations.
    
    **Features:**
    - Real-time AQI prediction
    - Health impact assessment
    - Visual AQI gauge
    - Personalized recommendations
    
    **Model:** Random Forest Regressor
    **Accuracy:** R² Score = 0.98
    
    **Developer:** Your Name
    **GitHub:** github.com/yourusername/aqi-predictor
    """)

# Display input summary
st.sidebar.markdown("---")
st.sidebar.markdown("### Current Inputs")
st.sidebar.dataframe(input_data, hide_index=True)
```

### Step 2: Install Dependencies

```bash
# requirements_streamlit.txt
streamlit==1.31.0
pandas==1.5.3
numpy==1.24.3
scikit-learn==1.3.0
plotly==5.18.0
joblib==1.3.2
```

### Step 3: Train and Save Model

```python
# train_and_save.py
import joblib
from aqi_prediction_simple import AQIPredictor

# Train model
predictor = AQIPredictor()
df = predictor.generate_sample_data(n_samples=5000)
df = predictor.preprocess_data(df)
X, y = predictor.prepare_features(df)
X_train, X_test, y_train, y_test = predictor.split_and_scale_data(X, y)
predictor.train_random_forest(X_train, y_train)

# Save model
model_data = {
    'model': predictor.models['Random Forest'],
    'scaler': predictor.scaler,
    'feature_names': ['pm25', 'pm10', 'no2', 'so2', 'o3', 'co']
}

joblib.dump(model_data, 'aqi_model.pkl')
print("✓ Model saved!")
```

### Step 4: Run Locally

```bash
# Install dependencies
pip install -r requirements_streamlit.txt

# Train and save model
python train_and_save.py

# Run app
streamlit run streamlit_app.py
```

**Access at:** http://localhost:8501

### Step 5: Deploy to Streamlit Cloud (FREE!)

1. Push code to GitHub:
```bash
git init
git add streamlit_app.py requirements_streamlit.txt aqi_model.pkl
git commit -m "Initial commit"
git push origin main
```

2. Go to https://share.streamlit.io
3. Connect your GitHub repo
4. Deploy!

**Your app will be live at:** `https://your-app.streamlit.app`

---

## 🔧 OPTION 2: Flask REST API

**Best for:** Mobile apps, other applications to call your model

### Step 1: Create Flask API

```python
# File: app.py

from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import numpy as np
import joblib

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend access

# Load model
model_data = joblib.load('aqi_model.pkl')
model = model_data['model']
scaler = model_data['scaler']

def categorize_aqi(aqi):
    """Convert AQI to category"""
    if aqi <= 50:
        return {"category": "Good", "color": "green", "impact": "Minimal"}
    elif aqi <= 100:
        return {"category": "Moderate", "color": "yellow", "impact": "Acceptable"}
    elif aqi <= 200:
        return {"category": "Poor", "color": "orange", "impact": "Unhealthy"}
    else:
        return {"category": "Severe", "color": "red", "impact": "Hazardous"}

@app.route('/')
def home():
    """Home endpoint"""
    return jsonify({
        "message": "AQI Prediction API",
        "version": "1.0",
        "endpoints": {
            "/predict": "POST - Predict AQI",
            "/health": "GET - Health check"
        }
    })

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy"}), 200

@app.route('/predict', methods=['POST'])
def predict():
    """
    Predict AQI from pollutant data
    
    Request body:
    {
        "pm25": 50,
        "pm10": 75,
        "no2": 40,
        "so2": 20,
        "o3": 60,
        "co": 1.5
    }
    """
    try:
        # Get data from request
        data = request.get_json()
        
        # Validate input
        required_fields = ['pm25', 'pm10', 'no2', 'so2', 'o3', 'co']
        for field in required_fields:
            if field not in data:
                return jsonify({"error": f"Missing field: {field}"}), 400
        
        # Create dataframe
        input_df = pd.DataFrame({
            'pm25': [data['pm25']],
            'pm10': [data['pm10']],
            'no2': [data['no2']],
            'so2': [data['so2']],
            'o3': [data['o3']],
            'co': [data['co']]
        })
        
        # Scale and predict
        input_scaled = scaler.transform(input_df)
        prediction = model.predict(input_scaled)[0]
        
        # Get category
        category_info = categorize_aqi(prediction)
        
        # Return response
        return jsonify({
            "success": True,
            "aqi": round(prediction, 2),
            "category": category_info["category"],
            "color": category_info["color"],
            "health_impact": category_info["impact"],
            "input": data
        })
    
    except Exception as e:
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
```

### Step 2: Test API Locally

```bash
# Install Flask
pip install flask flask-cors

# Run API
python app.py
```

### Step 3: Test with curl or Postman

```bash
# Test prediction
curl -X POST http://localhost:5000/predict \
  -H "Content-Type: application/json" \
  -d '{
    "pm25": 75,
    "pm10": 110,
    "no2": 45,
    "so2": 22,
    "o3": 65,
    "co": 1.8
  }'

# Response:
# {
#   "success": true,
#   "aqi": 142.5,
#   "category": "Poor",
#   "color": "orange",
#   "health_impact": "Unhealthy"
# }
```

### Step 4: Deploy to Heroku (FREE)

```bash
# Create Procfile
echo "web: gunicorn app:app" > Procfile

# Create requirements.txt
pip freeze > requirements.txt

# Initialize git
git init
git add .
git commit -m "Deploy to Heroku"

# Deploy to Heroku
heroku login
heroku create your-aqi-api
git push heroku main
```

**Your API is live at:** `https://your-aqi-api.herokuapp.com`

---

## 🐳 OPTION 3: Docker Container

**Best for:** Reproducibility, consistency across environments

### Step 1: Create Dockerfile

```dockerfile
# Dockerfile

FROM python:3.9-slim

WORKDIR /app

# Copy requirements
COPY requirements.txt .

# Install dependencies
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 8501

# Run Streamlit app
CMD ["streamlit", "run", "streamlit_app.py", "--server.port=8501", "--server.address=0.0.0.0"]
```

### Step 2: Create docker-compose.yml

```yaml
# docker-compose.yml

version: '3.8'

services:
  aqi-predictor:
    build: .
    ports:
      - "8501:8501"
    volumes:
      - ./aqi_model.pkl:/app/aqi_model.pkl
    environment:
      - PYTHONUNBUFFERED=1
```

### Step 3: Build and Run

```bash
# Build image
docker build -t aqi-predictor .

# Run container
docker run -p 8501:8501 aqi-predictor

# Or use docker-compose
docker-compose up
```

**Access at:** http://localhost:8501

### Step 4: Push to Docker Hub

```bash
# Tag image
docker tag aqi-predictor yourusername/aqi-predictor:latest

# Push to Docker Hub
docker push yourusername/aqi-predictor:latest
```

Now anyone can run your app with:
```bash
docker pull yourusername/aqi-predictor:latest
docker run -p 8501:8501 yourusername/aqi-predictor:latest
```

---

## ☁️ OPTION 4: AWS Lambda (Serverless)

**Best for:** Production, auto-scaling, pay-per-use

### Step 1: Create Lambda Handler

```python
# lambda_function.py

import json
import numpy as np
import joblib
import boto3

# Load model from S3
s3 = boto3.client('s3')
s3.download_file('your-bucket', 'aqi_model.pkl', '/tmp/aqi_model.pkl')
model_data = joblib.load('/tmp/aqi_model.pkl')

def lambda_handler(event, context):
    """AWS Lambda handler"""
    
    try:
        # Parse input
        body = json.loads(event['body'])
        
        # Create input array
        input_data = np.array([[
            body['pm25'],
            body['pm10'],
            body['no2'],
            body['so2'],
            body['o3'],
            body['co']
        ]])
        
        # Scale and predict
        input_scaled = model_data['scaler'].transform(input_data)
        prediction = model_data['model'].predict(input_scaled)[0]
        
        # Categorize
        if prediction <= 50:
            category = "Good"
        elif prediction <= 100:
            category = "Moderate"
        elif prediction <= 200:
            category = "Poor"
        else:
            category = "Severe"
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'aqi': float(prediction),
                'category': category
            })
        }
    
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
```

### Step 2: Package Dependencies

```bash
# Create deployment package
pip install -t package/ scikit-learn numpy joblib
cd package
zip -r ../lambda_deployment.zip .
cd ..
zip -g lambda_deployment.zip lambda_function.py aqi_model.pkl
```

### Step 3: Deploy to AWS

```bash
# Using AWS CLI
aws lambda create-function \
  --function-name aqi-predictor \
  --runtime python3.9 \
  --role arn:aws:iam::YOUR_ACCOUNT:role/lambda-role \
  --handler lambda_function.lambda_handler \
  --zip-file fileb://lambda_deployment.zip
```

---

## 📱 OPTION 5: Mobile-Friendly HTML/JS

**Best for:** Simple web deployment, GitHub Pages

```html
<!-- index.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AQI Predictor</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
        }
        .input-group {
            margin: 15px 0;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #666;
        }
        input[type="number"] {
            width: 100%;
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            width: 100%;
            padding: 15px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
        }
        button:hover {
            background: #764ba2;
        }
        #result {
            margin-top: 20px;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
        }
        .good { background: #4caf50; color: white; }
        .moderate { background: #ffeb3b; color: #333; }
        .poor { background: #ff9800; color: white; }
        .severe { background: #f44336; color: white; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🌍 AQI Predictor</h1>
        
        <div class="input-group">
            <label>PM2.5 (μg/m³)</label>
            <input type="number" id="pm25" value="50">
        </div>
        
        <div class="input-group">
            <label>PM10 (μg/m³)</label>
            <input type="number" id="pm10" value="75">
        </div>
        
        <div class="input-group">
            <label>NO₂ (μg/m³)</label>
            <input type="number" id="no2" value="40">
        </div>
        
        <div class="input-group">
            <label>SO₂ (μg/m³)</label>
            <input type="number" id="so2" value="20">
        </div>
        
        <div class="input-group">
            <label>O₃ (μg/m³)</label>
            <input type="number" id="o3" value="60">
        </div>
        
        <div class="input-group">
            <label>CO (mg/m³)</label>
            <input type="number" id="co" value="1.5" step="0.1">
        </div>
        
        <button onclick="predictAQI()">Predict AQI</button>
        
        <div id="result" style="display:none;"></div>
    </div>
    
    <script>
        async function predictAQI() {
            const data = {
                pm25: parseFloat(document.getElementById('pm25').value),
                pm10: parseFloat(document.getElementById('pm10').value),
                no2: parseFloat(document.getElementById('no2').value),
                so2: parseFloat(document.getElementById('so2').value),
                o3: parseFloat(document.getElementById('o3').value),
                co: parseFloat(document.getElementById('co').value)
            };
            
            // Call your API
            const response = await fetch('YOUR_API_URL/predict', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            // Display result
            const resultDiv = document.getElementById('result');
            resultDiv.style.display = 'block';
            resultDiv.className = result.category.toLowerCase();
            resultDiv.innerHTML = `
                AQI: ${result.aqi}<br>
                <small>${result.category}</small>
            `;
        }
    </script>
</body>
</html>
```

Deploy to GitHub Pages - FREE hosting!

---

## 📊 Comparison Table

| Feature | Streamlit | Flask API | Docker | AWS Lambda | HTML/JS |
|---------|-----------|-----------|--------|------------|---------|
| **Ease** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐ |
| **Cost** | Free | Free tier | Free | Pay-per-use | Free |
| **Speed** | Fast | Fast | Fast | Cold start | Instant |
| **Scaling** | Limited | Medium | Good | Excellent | N/A |
| **Best For** | Demo | API | Consistency | Production | Simple UI |

---

## 🎯 RECOMMENDED PATH FOR YOUR PROJECT

### Week 1: Local Development
```bash
1. Run locally: python aqi_prediction_simple.py
2. Test everything works
3. Save trained model
```

### Week 2: Web App (Streamlit)
```bash
1. Create streamlit_app.py
2. Test locally: streamlit run streamlit_app.py
3. Deploy to Streamlit Cloud (FREE!)
```

### Week 3: API (Optional - if time permits)
```bash
1. Create Flask API
2. Test with Postman
3. Deploy to Heroku (FREE!)
```

### Week 4: Documentation
```bash
1. Add deployment section to README
2. Create demo video
3. Update resume with "Deployed ML model as web app"
```

---

## ✅ Updated Resume Bullets

**Before:** ❌
> "Built a machine learning model to predict AQI"

**After:** ✅
> "Developed and deployed AQI prediction web application using Streamlit, serving 100+ users with real-time predictions and interactive visualizations"

**Advanced:** ⭐
> "Built end-to-end ML pipeline: trained Random Forest model (R²=0.98), containerized with Docker, and deployed REST API on Heroku with 99.9% uptime"

---

## 🎓 What to Show in Interview

1. **Live Demo:** "Here's my deployed app at [your-url]"
2. **Code Walkthrough:** "I used Flask to create REST API endpoints"
3. **Deployment Process:** "I containerized with Docker for reproducibility"
4. **Monitoring:** "The app logs all predictions for analysis"

This shows you can **build AND deploy** - a huge differentiator!

---

**Need help with any deployment option? Let me know which one you want to pursue!**
